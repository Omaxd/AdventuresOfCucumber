﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundInfo : MonoBehaviour {

    public AudioSource deathSound;
    public AudioSource enemyShot;
    public AudioSource throwSlice;
    public AudioSource openChest;
    public AudioSource fallingTrap;

}
