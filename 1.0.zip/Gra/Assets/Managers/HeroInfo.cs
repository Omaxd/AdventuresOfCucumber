﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;

public class HeroInfo : MonoBehaviour {

    public int MaxHp;
    public int CurrentHp;
    public int MaxResist;
    public int CurrentResist;
    public int MaxSlices;
    public int CurrentSlices;
    public int MoveSpeed;
    public int MaxSpeed;
    public int CanMakeDoubleJump; //0 lub 1
    public int Money;

    List<string> dataList;


    // Use this for initialization
    void Start () {
        Fill();
    }

    List<string> LoadFromFile()
    {
        dataList = new List<string>();
        string[] lines = File.ReadAllLines("Assets/File/Profile.txt");
        foreach (string line in lines)
        {
            foreach (string character in line.Split(' '))
            {
                dataList.Add(character);
            }
        }
        return dataList;
    }
    void Fill()
    {
        List<string> list = LoadFromFile();
        MaxHp=int.Parse(list[1]);
        CurrentHp = MaxHp;
        MaxResist = int.Parse(list[5]);
        CurrentResist = int.Parse(list[7]);
        MaxSlices = int.Parse(list[9]);
        CurrentSlices = MaxSlices;
        MoveSpeed = int.Parse(list[13]);
        MaxSpeed = int.Parse(list[15]);
        CanMakeDoubleJump = int.Parse(list[17]);
        Money = int.Parse(list[19]);
    }
}
