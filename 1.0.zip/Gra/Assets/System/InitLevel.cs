﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InitLevel : MonoBehaviour {

	void Start () {
        GameObject.Find("BramaW").SetActive(false);
        GameObject.Find("Ogor").gameObject.SetActive(false);
    }
}
