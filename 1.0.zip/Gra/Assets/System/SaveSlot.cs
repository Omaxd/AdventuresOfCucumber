﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

public class SaveSlot : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void Save()
    {
        FileStream file = File.Create(Application.persistentDataPath + "/heroInfo.data");

        BinaryFormatter binaryFormatter = new BinaryFormatter();
    }

    public void Load()
    {

    }
}

[Serializable]
public class SerializableSaveSlot
{
    //HeroInfo
    public int MaxSlices;
    public int MaxHp;

    //EconomyInfo
    public int Money;


    public SerializableSaveSlot() { }
}
