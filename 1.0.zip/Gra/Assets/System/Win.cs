﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Win : MonoBehaviour {

    public GameObject heroInfo;
    public GameObject GUImanager;
    public AudioSource win;

    void OnCollisionEnter(Collision other)
    {
        win.Play();
        string money = heroInfo.GetComponent<HeroInfo>().Money.ToString();
        string hp = heroInfo.GetComponent<HeroInfo>().CurrentHp.ToString();
        string slices = heroInfo.GetComponent<HeroInfo>().CurrentSlices.ToString();
        string time = GUImanager.GetComponent<DisplayManager>().time.ToString();
        using (System.IO.StreamWriter file =
            new System.IO.StreamWriter("Assets/File/Record.txt", true))
            {
                file.WriteLine("Time: "+time+" -- Money: "+money+" -- HP: "+hp+" -- Slices: "+slices);
            }
        SceneManager.LoadScene("Menu");

    }

}
