﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ButtonManager : MonoBehaviour {

    public void NewGameButton(string GameLevel)
    {
        SceneManager.LoadScene(GameLevel);
    }

    public void ExitGameButton()
    {
        Application.Quit();
    }

    public void HowToPlayButton()
    {
        SceneManager.LoadScene("HowToPlay");
    }
}
