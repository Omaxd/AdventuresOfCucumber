﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour {
 
    public Vector3 startingPosition;

    int moveSpeed;
    int hightOfJump;
    bool canJump;
    int canMakeDoubleJump;
    int maxLife;
    int currLife;

    public SliceAmmo sliceAmmo;

    void Start() {        
        canJump = true;
        moveSpeed = GameObject.Find("HeroInfo").GetComponent<HeroInfo>().MoveSpeed;
        canMakeDoubleJump = GameObject.Find("HeroInfo").GetComponent<HeroInfo>().CanMakeDoubleJump;
        maxLife = GameObject.Find("HeroInfo").GetComponent<HeroInfo>().MaxHp;
        currLife = maxLife;
        GetComponent<Transform>().position= new Vector3(-20, 17, -2);
    }

    void Update()
    {
        Debug.Log(GetComponent<Rigidbody>().velocity.x.ToString() +" "+GetComponent<Rigidbody>().velocity.y.ToString() +" "+GetComponent<Rigidbody>().velocity.z.ToString());
        Move();
        Transform();
        if (transform.position.y < -90) Dead();
    }

    void OnCollisionEnter(Collision other)
    {
        if (other.transform.tag == "Spikes" || other.transform.tag == "FallingBalls" || other.transform.tag == "Bullet")
        {
            Dead();
        }
    }

    public void Spawn()
    {
        transform.position = GameObject.Find("LevelInfo").GetComponent<LevelInfo>().spawnPlace;
    }
    void Dead()
    {
        GameObject.Find("SoundInfo").GetComponent<SoundInfo>().deathSound.Play();
        currLife--;
        GameObject.Find("HeroInfo").GetComponent<HeroInfo>().CurrentHp--;
        Spawn();
    }
    void Transform()
    {
        transform.localScale = new Vector3(transform.localScale.x, sliceAmmo.CurrentAmmo * 0.4f + 4, transform.localScale.z);
        hightOfJump = 20 + (int)((sliceAmmo.MaxAmmo * 2 - sliceAmmo.CurrentAmmo) * 0.5);
    }

    void Move()
    {      
        //Do przodu
        if (Input.GetButton("Forward")) GoForward();

        //Do tyłu
        if (Input.GetButton("Backward")) GoBackward();
        
        //Skok
        if (Input.GetButtonDown("Jump") && GetComponent<Rigidbody>().velocity.y == 0) Jump();
    }
    void GoForward()
    {
        GetComponent<Transform>().Translate(new Vector3(moveSpeed, 0, 0) * Time.deltaTime);
    }
    void GoBackward()
    {
        GetComponent<Transform>().Translate(new Vector3(-moveSpeed, 0, 0) * Time.deltaTime);
    }
    void Jump()
    {
        GetComponent<Rigidbody>().velocity = new Vector3(0, hightOfJump, 0);
    }


}
